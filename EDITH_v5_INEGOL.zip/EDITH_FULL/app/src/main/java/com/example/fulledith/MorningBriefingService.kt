package com.example.fulledith

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

/**
 * EDITH Sabah Brifing Servisi
 * OpenWeatherMap API ile gerçek zamanlı İnegöl hava durumu.
 */
class MorningBriefingService : Service(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private val briefingQueue = mutableListOf<String>()
    private var currentIndex  = 0

    companion object {
        const val CHANNEL_ID = "edith_morning"
        const val NOTIF_ID   = 1001

        // ── OpenWeatherMap ───────────────────────────────────────
        // openweathermap.org → ücretsiz kayıt → API key al → buraya yaz
        const val OWM_API_KEY = "BURAYA_API_KEY_YAZIN"

        // İnegöl koordinatları (sabit — her zaman doğru şehri getirir)
        const val INEGOL_LAT = 40.0767
        const val INEGOL_LON = 29.5092
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())
        return START_NOT_STICKY
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("tr", "TR")
            tts.setPitch(0.52f)
            tts.setSpeechRate(1.0f)

            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(uid: String?) {}
                override fun onDone(uid: String?) {
                    currentIndex++
                    if (currentIndex < briefingQueue.size) speakNext() else stopSelf()
                }
                override fun onError(uid: String?) { stopSelf() }
            })

            // Önce hava durumunu çek, sonra brifing kur
            fetchWeatherThenBuild()
        }
    }

    // ── Hava Durumu API ──────────────────────────────────────────
    private fun fetchWeatherThenBuild() {
        CoroutineScope(Dispatchers.IO).launch {
            val havaCumlesi = try {
                val url = URL(
                    "https://api.openweathermap.org/data/2.5/weather" +
                    "?lat=$INEGOL_LAT&lon=$INEGOL_LON" +
                    "&appid=$OWM_API_KEY&units=metric&lang=tr"
                )
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod  = "GET"
                    connectTimeout = 8000
                    readTimeout    = 8000
                }
                val json   = JSONObject(conn.inputStream.bufferedReader().readText())
                conn.disconnect()

                val sicaklik  = json.getJSONObject("main").getDouble("temp").toInt()
                val hissi     = json.getJSONObject("main").getDouble("feels_like").toInt()
                val nem       = json.getJSONObject("main").getInt("humidity")
                val tanim     = json.getJSONArray("weather")
                                    .getJSONObject(0).getString("description")
                val ruzgar    = json.getJSONObject("wind").getDouble("speed").toInt()

                val yagmurUyari = when {
                    tanim.contains("yağmur") || tanim.contains("sağanak") ->
                        " Şemsiyenizi almayı unutmayın."
                    tanim.contains("kar") ->
                        " Yollar kaygan olabilir, dikkatli olun."
                    else -> ""
                }

                "İnegöl'de şu an $tanim. Sıcaklık $sicaklik derece, " +
                "hissedilen $hissi derece. Nem yüzde $nem. " +
                "Rüzgar hızı saniyede $ruzgar metre.$yagmurUyari"

            } catch (e: Exception) {
                // API key girilmemişse veya internet yoksa yedek mesaj
                val mevsim = Calendar.getInstance().get(Calendar.MONTH)
                when {
                    mevsim in 11..12 || mevsim in 0..1 ->
                        "İnegöl'de bugün soğuk ve bulutlu hava bekleniyor."
                    mevsim in 2..4 ->
                        "İnegöl'de bugün ılık ve parçalı bulutlu hava bekleniyor."
                    mevsim in 5..8 ->
                        "İnegöl'de bugün sıcak ve güneşli hava bekleniyor."
                    else ->
                        "İnegöl'de bugün serin hava bekleniyor."
                }
            }

            withContext(Dispatchers.Main) {
                buildBriefing(havaCumlesi)
                speakNext()
            }
        }
    }

    // ── Brifing Metni ────────────────────────────────────────────
    private fun buildBriefing(havaCumlesi: String) {
        val cal       = Calendar.getInstance()
        val gun       = SimpleDateFormat("EEEE", Locale("tr")).format(cal.time)
        val tarih     = SimpleDateFormat("d MMMM yyyy", Locale("tr")).format(cal.time)
        val saat      = SimpleDateFormat("HH:mm", Locale("tr")).format(cal.time)
        val haftaGunu = cal.get(Calendar.DAY_OF_WEEK) in 2..6

        val prefs = getSharedPreferences("edith_prefs", Context.MODE_PRIVATE)
        val isim  = prefs.getString("kullanici_adi", "efendim") ?: "efendim"

        briefingQueue.clear()
        currentIndex = 0

        // 1. Açılış
        briefingQueue.add(
            "Günaydın $isim. Ben E.D.I.T.H. Bugün $gun, $tarih. Saat $saat. " +
            "İnegöl'den sabah brifingini sunuyorum."
        )

        // 2. Gerçek hava durumu
        briefingQueue.add(havaCumlesi)

        // 3. Motivasyon
        briefingQueue.add(getMotivasyonCumlesi(cal.get(Calendar.DAY_OF_YEAR)))

        // 4. Hafta içi / sonu
        briefingQueue.add(
            if (haftaGunu) "Bugün iş günü $isim. Takviminizdeki randevuları kontrol edin."
            else "Bugün hafta sonu. Güzel bir gün geçirin."
        )

        // 5. Kapanış
        briefingQueue.add("Sabah brifingim tamamlandı. İyi günler. EDITH bekleme moduna geçiyor.")
    }

    private fun speakNext() {
        if (currentIndex >= briefingQueue.size) return
        tts.speak(briefingQueue[currentIndex], TextToSpeech.QUEUE_FLUSH, null, "brief_$currentIndex")
    }

    private fun getMotivasyonCumlesi(dayOfYear: Int): String {
        val cumleler = listOf(
            "Bugün harika şeyler başarabilirsiniz. Sistemler hazır, siz de hazır olun.",
            "Her yeni gün yeni bir görev. Odaklanın ve ilerleyin.",
            "Stark diyor ki: Başarı tesadüf değil, plan ve kararlılıktır.",
            "Tüm engeller aşılabilir. Bugün de böyle olacak.",
            "Küçük adımlar büyük zaferler getirir. Başlayın.",
            "Bugünü en iyi şekilde değerlendirin. Zamanınız kıymetlidir.",
            "Güçlü bir zihin her şeyin üstesinden gelir. Siz güçlüsünüz."
        )
        return cumleler[dayOfYear % cumleler.size]
    }

    private fun buildNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("EDITH — Sabah Brifing")
            .setContentText("İnegöl hava durumu alınıyor...")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pi)
            .build()
    }

    private fun createNotificationChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "EDITH Sabah Bildirimleri", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        tts.shutdown()
        super.onDestroy()
    }
}
