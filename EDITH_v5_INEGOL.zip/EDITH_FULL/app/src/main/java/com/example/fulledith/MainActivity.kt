package com.example.fulledith

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false
    private var ttsReady = false
    private lateinit var statusText: TextView
    private lateinit var commandText: TextView
    private lateinit var hudOverlay: HUDOverlay
    private lateinit var messaging: MessagingManager

    // Mesaj bekleme durumu
    private var pendingAction: String? = null   // "sms_num", "sms_msg", "wa_num", "wa_msg", "tg_msg"
    private var pendingNumber: String = ""
    private var pendingMessage: String = ""

    companion object {
        const val PERMISSION_REQUEST = 200
        const val TAG = "EDITH"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        commandText = findViewById(R.id.commandText)
        hudOverlay = findViewById(R.id.hudOverlay)

        tts = TextToSpeech(this, this)
        messaging = MessagingManager(this)
        checkPermissions()

        // İlk açılışta sabah alarmını kur (varsayılan 07:00)
        AlarmScheduler.kur(this)
    }

    private fun checkPermissions() {
        val permissions = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS
        )
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), PERMISSION_REQUEST)
        } else {
            initVoice()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST) initVoice()
    }

    // ─── TTS INIT ────────────────────────────────────────────────
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("tr", "TR"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.language = Locale.US
            }
            tts.setPitch(0.52f)
            tts.setSpeechRate(1.05f)

            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    // Konuşma bitince tekrar dinlemeye başla
                    Handler(Looper.getMainLooper()).postDelayed({ startListening() }, 600)
                }
                override fun onError(utteranceId: String?) {
                    Handler(Looper.getMainLooper()).postDelayed({ startListening() }, 600)
                }
            })

            ttsReady = true
            speak("E.D.I.T.H. sistemi başlatıldı. Tüm sistemler aktif. Dinliyorum.")
        }
    }

    // ─── SESLİ TANIMA ────────────────────────────────────────────
    private fun initVoice() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                runOnUiThread {
                    isListening = true
                    statusText.text = "🎙️ DİNLİYORUM..."
                    hudOverlay.setListening(true)
                }
            }

            override fun onBeginningOfSpeech() {
                runOnUiThread { statusText.text = "🎤 SES ALINIYOR..." }
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull() ?: ""
                runOnUiThread {
                    commandText.text = "► $text"
                    isListening = false
                    hudOverlay.setListening(false)
                    processCommand(text.lowercase(Locale.getDefault()))
                }
            }

            override fun onError(error: Int) {
                runOnUiThread {
                    isListening = false
                    hudOverlay.setListening(false)
                    statusText.text = "⚡ HAZIR"
                }
                // Hata sonrası tekrar dinle
                Handler(Looper.getMainLooper()).postDelayed({ startListening() }, 1500)
            }

            override fun onRmsChanged(rmsdB: Float) {
                runOnUiThread { hudOverlay.setVolume(rmsdB) }
            }

            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull() ?: ""
                runOnUiThread { commandText.text = "... $partial" }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun startListening() {
        if (isListening || !ttsReady) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500)
        }
        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Listening error: ${e.message}")
        }
    }

    // ─── KOMUT İŞLEME ────────────────────────────────────────────
    private fun processCommand(cmd: String) {

        // ── Çok adımlı mesaj akışı ────────────────────────────────
        when (pendingAction) {
            "sms_num" -> {
                pendingNumber = cmd
                pendingAction = "sms_msg"
                speak("Mesajı söyleyin.")
                return
            }
            "sms_msg" -> {
                pendingMessage = cmd
                pendingAction = null
                val result = messaging.smsSend(pendingNumber, pendingMessage)
                speak(result)
                return
            }
            "wa_num" -> {
                pendingNumber = cmd
                pendingAction = "wa_msg"
                speak("Mesajı söyleyin. Sadece açmak istiyorsanız 'geç' deyin.")
                return
            }
            "wa_msg" -> {
                pendingMessage = if (cmd == "geç") "" else cmd
                pendingAction = null
                val result = messaging.whatsappAc(pendingNumber, pendingMessage)
                speak(result)
                return
            }
            "tg_msg" -> {
                pendingMessage = cmd
                pendingAction = null
                messaging.telegramGonder(pendingMessage) { speak(it) }
                speak("Telegram mesajı gönderiliyor.")
                return
            }
        }

        // ── Ana komutlar ──────────────────────────────────────────
        val response = when {

            // ── WhatsApp ──────────────────────────────────────────
            cmd.contains("whatsapp") && (cmd.contains("aç") || cmd.contains("mesaj")) -> {
                pendingAction = "wa_num"
                "Hangi numaraya mesaj atmak istiyorsunuz? Numarayı söyleyin."
            }
            cmd.contains("whatsapp") -> {
                messaging.whatsappAc()
                "WhatsApp açılıyor."
            }

            // ── SMS ───────────────────────────────────────────────
            cmd.contains("sms") || (cmd.contains("mesaj") && cmd.contains("gönder")) -> {
                pendingAction = "sms_num"
                "SMS göndereceğim. Alıcının numarasını söyleyin."
            }

            // ── Telegram ─────────────────────────────────────────
            cmd.contains("telegram") && cmd.contains("oku") -> {
                messaging.telegramOku { speak(it) }
                "Telegram mesajları okunuyor."
            }
            cmd.contains("telegram") -> {
                pendingAction = "tg_msg"
                "Telegram'a ne yazmamı istersiniz?"
            }

            // ── Selamlama ─────────────────────────────────────────
            cmd.contains("merhaba") || cmd.contains("selam") ->
                "Merhaba efendim. E.D.I.T.H. hizmetinizde."

            // ── Kimlik ────────────────────────────────────────────
            cmd.contains("kimsin") || (cmd.contains("kim") && cmd.contains("sin")) ->
                "Ben E.D.I.T.H. Even Dead I'm The Hero. Stark teknolojisi tabanlı yapay zeka."

            // ── Saat / Tarih ──────────────────────────────────────
            cmd.contains("saat") || cmd.contains("zaman") -> {
                val sdf = SimpleDateFormat("HH:mm", Locale("tr"))
                "Şu an saat ${sdf.format(Date())}."
            }
            cmd.contains("tarih") || cmd.contains("bugün") -> {
                val sdf = SimpleDateFormat("d MMMM yyyy", Locale("tr"))
                "Bugün ${sdf.format(Date())}."
            }

            // ── Kamera / Tarama ───────────────────────────────────
            cmd.contains("kamera") || cmd.contains("görüntü") ->
                "Kamera sistemi aktif. Çevre analizi başlatılıyor."
            cmd.contains("tara") || cmd.contains("analiz") ->
                "Çevre taraması başlatıldı. Tehdit tespit edilmedi."
            cmd.contains("yüz") || cmd.contains("kim bu") ->
                "Yüz tanıma motoru aktif. Veritabanında arama yapılıyor."

            // ── Sabah Bildirimi / Alarm ───────────────────────────
            cmd.contains("sabah") && (cmd.contains("kur") || cmd.contains("ayarla") || cmd.contains("alarm")) -> {
                val saatBul = Regex("(\\d{1,2})").findAll(cmd).map { it.value.toInt() }.toList()
                val saat    = saatBul.getOrElse(0) { 7 }
                val buCuk   = cmd.contains("buçuk") || cmd.contains("otuz")
                val dakika  = if (buCuk) 30 else saatBul.getOrElse(1) { 0 }
                AlarmScheduler.ayarla(this, saat, dakika)
                "Sabah brifing alarmı $saat saat ${if (dakika > 0) "$dakika dakikaya" else "sıfıra"} kuruldu."
            }
            cmd.contains("sabah alarmı iptal") || (cmd.contains("sabah") && cmd.contains("iptal")) -> {
                AlarmScheduler.iptalEt(this)
                "Sabah alarmı iptal edildi."
            }
            cmd.contains("sabah brifing") || cmd.contains("bülten") || cmd.contains("günaydın test") -> {
                startService(Intent(this, MorningBriefingService::class.java))
                "Sabah brifing başlatılıyor."
            }

            // ── Durum ─────────────────────────────────────────────
            cmd.contains("durum") || cmd.contains("rapor") ->
                "Tüm sistemler nominal. WhatsApp, SMS ve Telegram modülleri aktif."

            // ── Yardım ────────────────────────────────────────────
            cmd.contains("yardım") || cmd.contains("ne yapabilirsin") ->
                "WhatsApp aç, SMS gönder, Telegram mesajı gönder veya oku diyebilirsiniz. " +
                "Ayrıca saat, tarih, kamera ve çevre taraması yapabilirim."

            // ── Kapat ─────────────────────────────────────────────
            cmd.contains("kapat") || cmd.contains("dur") -> {
                statusText.text = "⏸ BEKLEME"
                "Bekleme moduna geçiyorum."
            }

            cmd.contains("teşekkür") || cmd.contains("sağ ol") ->
                "Her zaman efendim. Başka bir şey var mı?"

            cmd.contains("test") ->
                "Tüm sistemler operasyonel. Mesajlaşma modülleri hazır."

            cmd.isBlank() -> { startListening(); return }

            else -> "Komut alındı: $cmd. İşleniyor."
        }

        speak(response)
    }

    // ─── KONUŞ ───────────────────────────────────────────────────
    fun speak(text: String) {
        if (!ttsReady) return
        runOnUiThread { statusText.text = "🔊 KONUŞUYOR..." }
        val params = Bundle()
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, "EDITH_${System.currentTimeMillis()}")
    }

    // ─── YAŞAM DÖNGÜSÜ ───────────────────────────────────────────
    override fun onResume() {
        super.onResume()
        if (ttsReady && !isListening) {
            Handler(Looper.getMainLooper()).postDelayed({ startListening() }, 1000)
        }
    }

    override fun onPause() {
        super.onPause()
        speechRecognizer?.stopListening()
        isListening = false
    }

    override fun onDestroy() {
        tts.shutdown()
        speechRecognizer?.destroy()
        super.onDestroy()
    }
}
