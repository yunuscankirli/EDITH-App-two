package com.example.fulledith

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Her sabah AlarmManager tarafından tetiklenir.
 * MorningBriefingService'i başlatır.
 * BOOT_COMPLETED de dinlenir — telefon yeniden başlayınca alarm yeniden kurulur.
 */
class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            // Sabah alarmı
            "com.example.fulledith.MORNING_BRIEFING" -> {
                val serviceIntent = Intent(context, MorningBriefingService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent)
                } else {
                    context.startService(serviceIntent)
                }
                // Yarın için alarmı yeniden kur
                AlarmScheduler.kur(context)
            }

            // Telefon yeniden başladıysa alarmı tekrar kur
            Intent.ACTION_BOOT_COMPLETED -> {
                AlarmScheduler.kur(context)
            }
        }
    }
}
